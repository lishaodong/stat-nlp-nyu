package kylm.writer;

import kylm.model.ClassMap;

public interface ClassMapWriter {
	void writeClassMap(ClassMap ss);
}
